-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 24, 2023 at 01:04 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `marketplacedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
CREATE TABLE IF NOT EXISTS `cart` (
  `cart_id` int NOT NULL AUTO_INCREMENT,
  `quantity` int NOT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `product_id` int NOT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`cart_id`),
  KEY `product_id` (`product_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `quantity`, `added_date`, `product_id`, `user_id`) VALUES
(49, 1, '2023-10-24 01:01:16', 24, 4),
(48, 1, '2023-10-24 01:01:04', 27, 4),
(50, 1, '2023-10-24 01:02:07', 19, 10),
(51, 1, '2023-10-24 01:02:19', 33, 10);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `cat_id` int NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(255) NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_name`) VALUES
(1, 'Electronics'),
(2, 'Appliances'),
(3, 'Furniture'),
(4, 'Books'),
(8, 'Other');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `order_id` int NOT NULL AUTO_INCREMENT,
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `order_quantity` int NOT NULL,
  `order_total_amount` decimal(10,2) DEFAULT NULL,
  `order_status` varchar(255) DEFAULT NULL,
  `buyer_id` int NOT NULL,
  `product_id` int NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `buyer_id` (`buyer_id`),
  KEY `FK_orders_product_id` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `order_date`, `order_quantity`, `order_total_amount`, `order_status`, `buyer_id`, `product_id`) VALUES
(14, '2023-10-22 02:05:25', 1, '3000.00', 'complete', 4, 19),
(15, '2023-10-22 16:28:19', 1, '3500.00', 'pending', 4, 21),
(16, '2023-10-23 16:54:03', 1, '3000.00', 'complete', 10, 19);

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
CREATE TABLE IF NOT EXISTS `payments` (
  `payment_id` int NOT NULL AUTO_INCREMENT,
  `payment_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `payment_method` varchar(255) NOT NULL,
  `payment_amount` decimal(10,2) NOT NULL,
  `order_id` int NOT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `order_id` (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `payment_date`, `payment_method`, `payment_amount`, `order_id`) VALUES
(1, '2023-10-22 00:40:46', 'PayPal', '3000.00', 12),
(2, '2023-10-22 02:05:25', 'Visa', '3000.00', 14),
(3, '2023-10-23 16:54:03', 'Visa', '3000.00', 16);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `product_id` int NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL,
  `product_description` text NOT NULL,
  `product_price` decimal(10,2) NOT NULL,
  `product_condition` varchar(255) NOT NULL,
  `product_quantity` int NOT NULL,
  `product_date_of_upload` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `product_image_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `cat_id` int NOT NULL,
  `seller_id` int NOT NULL,
  PRIMARY KEY (`product_id`),
  KEY `FK_products_seller_id` (`seller_id`),
  KEY `FK_products_cat_id` (`cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `product_description`, `product_price`, `product_condition`, `product_quantity`, `product_date_of_upload`, `product_image_url`, `cat_id`, `seller_id`) VALUES
(19, 'Lenovo i3 Notebook', 'It is great for office work, It has a fast working processor, an Intel core i3 7th generation processor, and Intel UHD graphics for standard gaming.', '3000.00', 'Like New', 4, '2023-10-24 00:06:15', 'uploads/Two_Laptops.jpg', 1, 4),
(21, 'Dixon Bar Fridge', 'Great for cooling drinks and has an ice dispenser.', '2000.00', 'Good', 1, '2023-10-24 00:07:29', 'uploads/fridge.jpg', 2, 4),
(24, 'Tom Dixon Study Desk', 'Meticulously crafted study desk that seamlessly blends functionality with aesthetic appeal.', '500.00', 'Good', 1, '2023-10-24 00:12:48', 'uploads/desk.jpg', 3, 7),
(25, 'HP Smart Tank Office Printer', 'Designed for heavy-duty use, it combines functionality with user-friendly features to streamline printing tasks within an office setting.', '1500.00', 'New', 1, '2023-10-24 00:15:07', 'uploads/printer.jpg', 1, 7),
(26, 'Collection Of Textbooks', 'This collection comprises a Geometry textbook, Biology etc', '500.00', 'Good', 5, '2023-10-24 00:21:09', 'uploads/textbooks.jpg', 4, 10),
(27, 'Dell Laptop', 'Has been used for 5 years now but still works like a charm and has a 500GB HDD storage drive and an Intel Celeron processor', '1500.00', 'Fair', 1, '2023-10-24 00:23:26', 'uploads/dell.jpg', 1, 10),
(28, 'Russell Hobbs Microwave', 'Compact in size and sleek in design. it is designed for convenient and efficient cooking and heating', '2000.00', 'Like New', 1, '2023-10-24 00:26:04', 'uploads/micro.jpg', 2, 10),
(29, 'Lenovo i5 Laptop', 'Great for gaming, it has an Intel UHD G1 graphics card and the processor is an i5 11th generation processor.', '5000.00', 'Like New', 1, '2023-10-24 00:30:10', 'uploads/Closed_Laptop.jpg', 1, 10),
(30, 'BMX bike', 'Great for mountain biking and for day-to-day travels', '200.00', 'Good', 1, '2023-10-24 00:31:57', 'uploads/bmx.jpg', 8, 10),
(31, 'Skate Board', 'Slick design and is great for individuals who are new to skating.', '500.00', 'New', 1, '2023-10-24 00:33:26', 'uploads/penny board.jpg', 8, 10),
(32, 'Laundry Basket', 'It may look small but can carry large loads of clothing.', '150.00', 'New', 1, '2023-10-24 00:42:00', 'uploads/laundry basket.jpg', 8, 7),
(33, 'DH Wallet', 'Slick design and is great for individuals who don\'t carry lots of cards or cash', '500.00', 'New', 1, '2023-10-24 00:53:28', 'uploads/wallet.jpg', 8, 4);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL,
  `user_lastname` varchar(255) NOT NULL,
  `user_tel_no` varchar(255) NOT NULL,
  `user_student_email` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_place_of_residence` varchar(255) NOT NULL,
  `user_role` varchar(255) NOT NULL,
  `user_registration_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_lastname`, `user_tel_no`, `user_student_email`, `user_password`, `user_place_of_residence`, `user_role`, `user_registration_date`) VALUES
(8, 'Sihle', 'Hlope', '0798765432', 'leo34leo95@gmail.com', '$2y$10$KyWmxxJUBNxmkE/9J6Bgw.8rZ73YE0DSCQlbi5LxG5ZjXCPih.Yy.', 'Mountain House', 'Customer', '2023-10-23 01:15:36'),
(4, 'David', 'Hope', '0727762597', '221069054@mycput.ac.za', '$2y$10$7ai6/wK2Ry.l2mAolYfDDOC.iZdyOdwTzRNYDJw48wMcob9DsYNFq', 'City Edge', 'Customer', '2023-10-23 01:16:50'),
(7, 'Leonard', 'Langa', '0727762597', 'langaleonard97@gmail.com', '$2y$10$tSCas9hwJSzy0L6si1xwn.IMI40.ORlqqIewuPkftfhIIaIpAZ4dS', 'New Market Junction', 'Admin', '2023-10-22 03:16:59'),
(10, 'Emanuel', 'Stevens', '0799567812', '123456789@mycput.ac.za', '$2y$10$D0z.x7QjbaABI94vAkU6y.TJaqkKUDVxEQ70V5h1m7erOhtftYquW', 'Catsville', 'Customer', '2023-10-23 16:45:47');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
